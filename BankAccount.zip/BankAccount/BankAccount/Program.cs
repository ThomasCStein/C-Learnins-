﻿using System;


namespace BankAccount
{
    class Program
    {
        static void Main(string[] args)
        { 
            //Default info
            //"Thomas", 189227, "1620 Sometreet Mount Vernon, WA 98273", "8082026006", false

            //Instantiate an object of Checking and savings
            CheckingAccount CheckingAccount1 = new CheckingAccount(0, 3);
            CheckingAccount1.Name = "Thomas S.";
            CheckingAccount1.AccountNumber = 189227;
            CheckingAccount1.Address = "1620 Sometreet Mount Vernon, WA 98273";
            CheckingAccount1.PhoneNumber = "8082026006";
            CheckingAccount1.VIPAccount = false;
            SavingsAccount SavingsAccount1 = new SavingsAccount(0, 6, .03);
            //Credit 150 to Checking
            Console.WriteLine($"How much would you Like to Credit to checking account? (150)");
            double Amount = Convert.ToDouble(Console.ReadLine());
            CheckingAccount1.CreditAccount(Amount);
            //Debit 50 from savings
            Console.WriteLine("How much to Debit from Savings account? (50)");
            Amount = Convert.ToDouble(Console.ReadLine());
            SavingsAccount1.DebitAccount(Amount);
            //Transfer 75 from Checking to Savings
            Console.WriteLine($"How much to transfer from Checking to Savings...(75)");
            Amount = Convert.ToDouble(Console.ReadLine());
            CheckingAccount1.DebitAccount(Amount);
            SavingsAccount1.CreditAccount(Amount);
            
            //Display all Checking account information.
            Console.WriteLine(CheckingAccount1.Name);
            Console.WriteLine(CheckingAccount1.AccountNumber);
            Console.WriteLine(CheckingAccount1.Balance);
            Console.WriteLine(CheckingAccount1.Address);
            Console.WriteLine(CheckingAccount1.PhoneNumber);
            Console.WriteLine(CheckingAccount1.VIPAccount);

            //Methods to show they call from Base class
            CheckingAccount1.SuspendAccount();
            CheckingAccount1.CloseAccount();
            CheckingAccount1.MakeVIP();
        }
    }
}
