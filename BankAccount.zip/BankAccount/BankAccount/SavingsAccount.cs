﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    class SavingsAccount 
    {
        private double _balance;
        private int _accountPostfix;
        private double _vipInterestRate;
            
        public double  Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }
        public int AccountPostFix
        {
            get { return _accountPostfix; }
            set { _accountPostfix = value; }
        }
        //ASK PROFFESOR, ARE PROPERTIES LIKE UNASSEMBLED CTORS FOR FIELDS? 
        private double VIPInterestRate
        {
            get { return _vipInterestRate; }
            set { _vipInterestRate = value; }
        }
        public SavingsAccount(double Balance, int AccountPostFix, double VIPInterestRate)
        {
            this._balance = Balance;
            this._accountPostfix = AccountPostFix;
            this._vipInterestRate = VIPInterestRate;
        }
       
        //METHODS
        public void DebitAccount(double amount)
        {
            //User supplied amount
            this.Balance -= amount;
            Console.WriteLine($"New savings balance for is: {this.Balance:0.00}");
        }
        public void CreditAccount(double amount)
        {
            //User supplied amount
            this.Balance += amount;
            Console.WriteLine($"New savings balance for is: {this.Balance:0.00}");
        }
    }
}
