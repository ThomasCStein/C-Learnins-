﻿using System;
using System.Collections.Generic;
using System.Text;


namespace BankAccount
{
    class CheckingAccount : Account
    {
        
        private double _balance;
        private int _accountPostfix;
        public double Balance
        {
            get { return _balance; }
            set { _balance = value; }
        }
        public int AccountPostFix
        {
            get { return _accountPostfix; }
            set { _accountPostfix = value; }
        }
        public CheckingAccount(double Balance, int AccountPostfix) : base()
        {
            this._balance = Balance;
            this._accountPostfix = AccountPostfix;
        }
        
        public void DebitAccount(double amount)
        {
            //User supplied amount
            this.Balance -= amount;
            Console.WriteLine($"New checking balance for {this.Name} is: {this.Balance:0.00}");
            //Add new balance and check for overwithdrawl
        }
        public void CreditAccount(double amount)
        {
            //User supplied amount
            this.Balance +=  amount;
            Console.WriteLine($"New checking balance for {this.Name} is: {this.Balance:0.00}");
        }
       
    }
}
