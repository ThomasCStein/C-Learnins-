﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    class Account
    {
       
        //Make private fields with _ and camelCase
        private string _name;
        private int _acctNumber;
        private string _address;
        private string _phone;
        private bool _vipAccount;
        //Make Properties PascalCase
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int AccountNumber
        {
            get { return _acctNumber; }
            set { _acctNumber = value; }
        }
        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        public string PhoneNumber
        {
            get { return _phone; }
            set { _phone = value; }
        }
        public bool VIPAccount
        {
            get { return _vipAccount; }
            set { _vipAccount = value; }
        }
        public Account()
        {

        }
        public Account(string Name, int AccountNumber, string Address, string Phone, bool VIPAccount)
        {
            this._name = Name;
            this._acctNumber = AccountNumber;
            this._address = Address;
            this._phone = Phone;
            this._vipAccount = VIPAccount;
        }
        
        //methods
        public void CloseAccount()
        {
            Console.WriteLine($"Account {this.AccountNumber} is closed.");
        }
        public void SuspendAccount()
        {
            Console.WriteLine($"The account for {this.Name} has been suspended.");
        }
        public void MakeVIP()
        {
            Console.WriteLine($"The account for {this.Name} is now VIP.");
        }
    }
}

